import React from "react";

export const ReactComponent = ({ name, music }) => (
  <div>
    {name} {music}
  </div>
);
