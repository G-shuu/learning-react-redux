import React from "react";

export class ClassComponent3 extends React.Component {
  render() {
    return <div>ClassComponent3</div>;
  }
}
