import React from "react";

class ClassComponent2 extends React.Component {
  render() {
    return <div>ClassComponent2</div>;
  }
}

export default ClassComponent2;
